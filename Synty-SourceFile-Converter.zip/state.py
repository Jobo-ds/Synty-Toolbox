import bpy

# state.py
flagged_complex_materials = []
generated_material_counter = 1
